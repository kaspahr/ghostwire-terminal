# S.O.L.E.M. — Civilian Continuity Archive

**Ghostwire Terminal** is a static civilian-facing archive page for S.O.L.E.M. materials.

This repository currently functions as a lightweight archive host for:

- Civilian dossier page images
- Civilian graphics and icon assets
- BOOT.wav
- DSYNC.mp3
- A single-page archive interface in `index.html`

## Current identity

**Civilian layer only.**

The site is intentionally simple and readable. It avoids simulated clearance gates, recruit portals, or restricted-system framing. Internal, technical, and restricted materials are intentionally withheld from this layer.

## Primary file

`index.html`

The homepage includes:

- Status section
- Direct file links
- Embedded civilian dossier pages
- Image asset gallery
- Browser-native audio players
- Updated footer/date
- Responsive layout for desktop and mobile

## Asset references

The page expects these files to remain in the repository root:

- `1900s 2.png`
- `civilian 1.png`
- `civilian 2.png`
- `civilian icon.png`
- `gold icon.png`
- `CIVILIAN_DOSSIER_Page_1.jpg`
- `CIVILIAN_DOSSIER_Page_2.jpg`
- `CIVILIAN_DOSSIER_Page_3.jpg`
- `CIVILIAN_DOSSIER_Page_4.jpg`
- `CIVILIAN_DOSSIER_Page_5.jpg`
- `CIVILIAN_DOSSIER_Page_6.jpg`
- `BOOT.wav`
- `DSYNC.mp3`

## Archive note

Because memory is a choice.
